# Python API Development with Flask & Mysql


# Setup
This instructions assume knowledge of flask, so installing flask will be skipped
Optional flask-basicauth module is included, username/pass set in config.py (default: user/pass)

## Install required modules
pip install pymysql
pip install flask_sqlalchemy
pip install mysql-connector-python
pip install flask-basicauth

## Mysql setup
Setup assumes mysql installed on localhost, port 3306
revise the URI parameters within main.connectToDB() (mysql-connector) 
and config.py (SQAlchemy/pymysql) accordingly
 

## Deployment
Can be set up locally for testing with >> python main.py
Then navigate your browser to localhost displayed by python in the commandline (i.e. http://127.0.0.1:Port/)
The frontend included at url path '/' allows API testing and displaying of results

## Cloud Deployment
Can be set up in cloud with Gunicorn, >> gunicorn wsgi
For cloud deployment, requirements.txt will need to be added and SECRET_KEY changed

##  API Documentation
API routes are documented within the main.py file, and linked to within the frontend (URL /) and include:

## Project list:
'/API/all', methods = ["GET"]

## Project update:
'/API/update', methods = ["PUT","PATCH"]
(Currently only PUT is used)

## Create note:
'/API/notes/add', methods = ["POST"]

## Update note:
'/API/notes/update', methods = ["PUT"]

## Delete note:
'/API/notes/delete/<var1>', methods = ["DELETE"]
var1 is the note_id to be deleted

## Example of data types assumed to be sent from the frontend can be viewed within the frontend or frontend/js/update.js