from main import db


class Notes(db.Model): #ORM for notes database. TBD: add ORM for projects database
    project_id=db.Column(db.Integer,unique=False)
    note_id=db.Column(db.Integer,primary_key=True)
    note=db.Column(db.String(2000),unique=False)
    def __init__(self,project_id,note_id,note):
        self.project_id=project_id
        self.note_id=note_id
        self.note=note

        
def addNote(projectID,noteID,note):
    newNote=Notes(projectID,noteID,note)
    db.create_all() #TBD remove this
    db.session.add(newNote)
    db.session.commit()
    print("Added note ",noteID)
    
def updateNote(projectID,noteID,note):
    Notes.query.filter_by(note_id=noteID).update({"note":note})
    db.session.commit()
    print("Updated note ",noteID)


def deleteNote(noteID):
    Notes.query.filter_by(note_id=noteID).delete()
    db.session.commit()
    print("Deleted note ",noteID)
    
def printNotes():    
    allNotes = Notes.query.all()
    print(allNotes)    
def getNoteById(note_id):
    note=Notes.query.filter_by(note_id=note_id).first()
    return note


def testAddDeleteNotes(): #Used for debugging or creating notes without a frontend
    try:
        addNote(1,200,"This note was a test add on 2020-10-3")
        addNote(1,201,"This note was a 2nd test add on 2020-10-3")
    except:
        db.session.rollback()
        print("could not add note(s), does note already exist?")

    try:
        printNotes()
        deleteNote(200)
        printNotes()
    except:
        print("could not delete note, does note exist?")
